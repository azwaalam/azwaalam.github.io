// Trippy Lines
// Azwa Alam
// Major Project #3


let pArray = [];

function setup() {
  createCanvas(windowWidth, windowHeight);
  background(0);
}

function draw() {
  pArray.push(new Particle(mouseX, mouseY));
  for (let i = 0; i < pArray.length; i++){
    pArray[i].move();
    pArray[i].display();
  }
}
function mouseClicked(){
  pArray.push(new Particle(mouseX, mouseY));
}
class Particle{
  constructor(x_, y_){
    this.scale = 10;
    this.x = 0;
    this.y = 0;
    this.c = color(random(255), random(255),random(255));
    this.size = random(10,20);
    this.xOff = random(10);
    this.yOff = random(10);
    this.ySpeed = noise(this.yOff) * this.scale;
    this.xSpeed = noise(this.xOff) *this.scale;
    this.angle = random(0,2*PI); //draws a circle 
  }
  move(){
    this.x += this.xSpeed; //change the position based on x
    this.y += this.ySpeed; //change the position based on y 
    this.xOff += random(1, 100);  //controls the direction of lines
    this.yOff += random(1, 100); //controls the direction of lines
    this.ySpeed = noise(this.yOff) * this.scale;
    this.xSpeed = noise(this.xOff) * this.scale;
  }
  display(){
    stroke(this.c);
    push();
    translate(width/2,height/2);
    rotate(this.angle); //spinning in directions
    translate(this.x,this.y);
    line(0,0,this.xSpeed, this.ySpeed);
    pop();
  }
}
